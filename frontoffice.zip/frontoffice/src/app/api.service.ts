// api.service.ts
// api.service.ts

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

import { Supermarket } from './models/supermarket.model';
import { Category } from './models/category.model';
import { Product } from './models/product.model';
import { Favorite } from './models/favorite.model';
import { User } from './models/user.model';
import { Order } from './models/order.model';
import { Notification } from './models/notification.model';
import { Review } from './models/review.model';

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  private baseUrl = 'http://localhost:3000/api';

  constructor(
    private http: HttpClient,
    private router: Router,
  ) {}

  url(): string {
    return this.baseUrl;
  }

  // PRODUCT
  getProducts(search: string, category: string, supermarket: string, page: number): Observable<Product[]> {
    return this.http.get<Product[]>(
      `${this.baseUrl}/products?search=${search}&category=${category}&supermarket=${supermarket}&page=${page}`,
    );
  }

  getCategories(): Observable<Category[]> {
    return this.http.get<Category[]>(`${this.baseUrl}/categories`);
  }

  getSupermarkets(): Observable<Supermarket[]> {
    return this.http.get<Supermarket[]>(`${this.baseUrl}/supermarkets`);
  }

  // AUTH
  postAuthLogin(email: string, password: string): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/auth/login`, {
      email,
      password,
    });
  }

  postAuthRegister(data: any): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/auth/register`, data);
  }

  getAuthMe(): Observable<User> {
    return this.http.get<User>(`${this.baseUrl}/auth/me`);
  }

  navigate(url: string): Promise<boolean> {
    return this.router.navigate([url]);
  }

  // FAVORITES
  getFavorites(): Observable<Favorite> {
    return this.http.get<Favorite>(`${this.baseUrl}/favorites`);
  }

  addFavorite(productId: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/products/${productId}/favorite`, {});
  }

  removeFavorite(productId: string): Observable<any> {
    return this.http.delete(`${this.baseUrl}/products/${productId}/favorite`);
  }

  addFavoriteSupermarket(supermarketId: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/supermarkets/${supermarketId}/favorite`, {});
  }

  removeFavoriteSupermarket(supermarketId: string): Observable<any> {
    return this.http.delete(`${this.baseUrl}/supermarkets/${supermarketId}/favorite`);
  }

  getRelatedProducts(name: string): Observable<Product> {
    return this.http.get<Product>(`${this.baseUrl}/products?search=${name}&page=1`);
  }

  // SUPERMARKETS
  getSupermarketById(id: string): Observable<Supermarket> {
    return this.http.get<Supermarket>(`${this.baseUrl}/supermarkets/${id}`);
  }

  // USER
  putUser(id: string, data: any): Observable<User> {
    return this.http.put<User>(`${this.baseUrl}/users/${id}`, data);
  }

  // ORDERS
  getOngoingOrders() {
      return this.http.get<Order[]>(`${this.baseUrl}/orders/ongoing`);
  }

  getFinishedOrders() {
    return this.http.get<Order[]>(`${this.baseUrl}/orders/finished`,);
  }
  
  cancelOrder(id: string) {
    return this.http.put(`${this.baseUrl}/orders/${id}/cancel`, {});
  }

  createOrder(data: any) {
    return this.http.post(`${this.baseUrl}/orders`, data);
  }

  createPayment(orderId: string) {
    return this.http.put<any>(`${this.baseUrl}/orders/${orderId}/payment`, {});
  }

  getOrdersCount() {
    return this.http.get<{ count: number }>(`${this.baseUrl}/orders/count`);
  }

  // NOTIFICATIONS
  getNotifications(): Observable<Notification[]> {
    return this.http.get<Notification[]>(`${this.baseUrl}/notifications`);
  }

  markNotificationsAsRead() {
   return this.http.put(`${this.baseUrl}/notifications/read`, {});
  }

  markNotificationAsRead(id: string) {
    return this.http.put(`${this.baseUrl}/notifications/${id}/read`, {});
  }


  // REVIEWS
  getSupermarketReviews(id: string): Observable<Review[]> {
    return this.http.get<Review[]>(`${this.baseUrl}/supermarkets/${id}/reviews`);
  }

  createReview(data: Review) {
    return this.http.post(`${this.baseUrl}/reviews`,data);
  }
    

}
