import { Injectable, signal } from '@angular/core';
import * as DarkReader from 'darkreader';

@Injectable({
  providedIn: 'root',
})
export class ColorThemeService {
  darkMode = signal(false);

  constructor() {
    const savedTheme = localStorage.getItem('theme');

    if (savedTheme === 'dark') {
      this.enableDarkMode();
    }
  }


  toggleTheme() {
    if (this.darkMode()) {
      this.disableDarkMode();
    } else {
      this.enableDarkMode();
    }
  }

  enableDarkMode() {
    this.darkMode.set(true);

    DarkReader.enable({
      brightness: 121, contrast: 70, sepia: 10
    })

    localStorage.setItem('theme', 'dark');
  }

  disableDarkMode() {
    this.darkMode.set(false);
    DarkReader.disable();
    localStorage.setItem('theme', 'light');
  }
}
