// services/product.service.ts

import { Injectable, signal } from '@angular/core';
import { ApiService } from '../api.service';
import { Supermarket } from '../models/supermarket.model';
import { Favorite } from '../models/favorite.model';
import { Product } from '../models/product.model';
import { Category } from '../models/category.model';

@Injectable({ providedIn: 'root' })
export class ProductService {
  loading = signal<boolean>(false);

  products = signal<Product[]>([]);
  categories = signal<Category[]>([]);
  supermarkets = signal<Supermarket[]>([]);
  currentPage = signal(1);
  hasMore = signal(true);

  favorites = signal<string[]>([]);
  favoriteSupermarkets = signal<string[]>([]);

  constructor(private api: ApiService) {}

  loadProducts(search: string, category: string, supermarket: string, append = false) {
    if (!append) this.currentPage.set(1);
    this.loading.set(true);

    this.api.getProducts(search, category, supermarket, this.currentPage()).subscribe({
      next: (data: Product[]) => {
        if (append) {
          this.products.update((p) => [...p, ...data]);
        } else {
          this.products.set(data);
        }
        this.hasMore.set(data.length > 0);
        this.loading.set(false);
      },
      error: () => {
        this.loading.set(false);
      },
    });
  }

  loadMore(search: string, category: string, supermarket: string) {
    this.currentPage.update((p) => p + 1);
    this.loadProducts(search, category, supermarket, true);
  }

  loadCategories() {
    this.api.getCategories().subscribe((data) => this.categories.set(data));
  }

  loadSupermarkets() {
    this.api.getSupermarkets().subscribe((data: Supermarket[]) => {
      this.supermarkets.set(data);

      if (!sessionStorage.getItem('featuredSupermarkets')) {
        const shuffled = [...data].sort(() => Math.random() - 0.5).slice(0, 4);
        sessionStorage.setItem('featuredSupermarkets', JSON.stringify(shuffled));
      }
    });
  }

  sortAsc = true;

  selectedProduct = signal<Product | null>(null);
  relatedProducts = signal<Product[]>([]);

  abrirModal(product: Product) {
    this.selectedProduct.set(product);
    this.loading.set(true);
    this.api.getRelatedProducts(product.name).subscribe((data: any) => {
      const relacionados = data.filter((p: any) => p._id !== product._id);
      this.relatedProducts.set(relacionados);
      this.loading.set(false);
    });
  }

  fecharModal() {
    this.selectedProduct.set(null);
    this.relatedProducts.set([]);
  }

  sortRelated(asc: boolean) {
    this.relatedProducts.update((items) =>
      [...items].sort((a, b) => (asc ? a.price - b.price : b.price - a.price)),
    );
  }

  sortProducts(asc: boolean) {
  this.products.update((items) =>
    [...items].sort((a, b) =>
      asc ? a.price - b.price : b.price - a.price
    )
  );
}


}
