import { Injectable, signal, computed } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class CartService {
  items = signal<any[]>(JSON.parse(localStorage.getItem('cart') || '[]'));
  cartOpen = signal(false);
  message = signal('');
  messageProductId = signal('');

  total = computed(() => {
    let soma = 0;
    for (let i = 0; i < this.items().length; i++) {
      let item = this.items()[i];
      soma += item.price * item.quantity;
    }
    return soma;
  });

  removeItem(id: string) {
    const listaAntiga = this.items();
    const listaNova = [];

    for (let i = 0; i < listaAntiga.length; i++) {
      if (listaAntiga[i]._id !== id) {
        listaNova.push(listaAntiga[i]);
      }
    }

    this.items.set(listaNova);
    this.saveCart();
  }

  clearCart() {
    this.items.set([]);
    this.saveCart();
  }

  addToCart(produtoNovo: any) {
    const listaAtual = [...this.items()];
    if (listaAtual.length > 0) {
      const primeiroItem = listaAtual[0];

      const primeiroSupermarketId =
        primeiroItem.supermarket?._id || primeiroItem.supermarket;

      const novoSupermarketId =
        produtoNovo.supermarket?._id || produtoNovo.supermarket;

      if (primeiroSupermarketId !== novoSupermarketId) {
        this.message.set('Só podes adicionar produtos do mesmo supermercado');
        this.messageProductId.set(produtoNovo._id);
        return;
      }
    }

    let encontrado = false;
    for (let i = 0; i < listaAtual.length; i++) {
      if (listaAtual[i]._id === produtoNovo._id) {
        if (listaAtual[i].quantity >= listaAtual[i].stock) {
          this.message.set('Quantidade máxima em stock atingida');
          this.messageProductId.set(produtoNovo._id);
          return;
        }
        listaAtual[i].quantity += 1;
        encontrado = true;
        break;
      }
    }

    if (!encontrado) {
      listaAtual.push({ ...produtoNovo, quantity: 1 });
    }
    this.message.set('');
    this.messageProductId.set('');

    this.items.set(listaAtual);
    this.saveCart();
  }

  increaseQuantity(id: string) {
    this.items.update((items) =>
      items.map((item) => {
        if (item._id === id && item.quantity < item.stock) {
          return { ...item, quantity: item.quantity + 1 };
        }
        return item;
      }),
    );
    this.saveCart();
  }

  decreaseQuantity(id: string) {
    this.items.update((items) =>
      items.map((item) =>
        item._id === id ? { ...item, quantity: Math.max(1, item.quantity - 1) } : item,
      ),
    );
    this.saveCart();
  }

  canAdd(product: any) {
    const items = this.items();
    if (items.length === 0) return true;
    return items[0].supermarket?._id === product.supermarket?._id;
  }

  toggleCart() {
    this.cartOpen.update(v => !v);
  }

  closeCart() {
    this.cartOpen.set(false);
  }

  get itemCount() {
    let total = 0;

    for (const item of this.items()) {
      total += item.quantity;
    }

    return total;
  }

  saveCart() {
    localStorage.setItem('cart', JSON.stringify(this.items())); 
  }
  
}
