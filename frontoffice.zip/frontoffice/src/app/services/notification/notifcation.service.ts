import { Injectable, signal } from '@angular/core';

import { ApiService } from '../../api.service';
import { Notification } from '../../models/notification.model';

@Injectable({
  providedIn: 'root',
})
export class NotificationService {
  notifications = signal<Notification[]>([]);
  loadingNotifications = signal(false);
  loadingMarkAll = signal(false);
  loadingSingle = signal<string[]>([]);

  constructor(private api: ApiService) {}

  loadNotifications() {
    this.loadingNotifications.set(true);
    this.api.getNotifications().subscribe({
      next: (data) => {
        this.notifications.set(data);
        this.loadingNotifications.set(false);
      },
      error: (err) => {
        console.error(err);
        this.loadingNotifications.set(false);
      },
    });
  }

  get unreadCount() {
    return this.notifications().filter((n) => !n.seen).length;
  }

  markAllAsRead() {
    this.loadingMarkAll.set(true);
    this.api.markNotificationsAsRead().subscribe({
      next: () => {
        const updated = this.notifications().map((n) => ({ ...n, seen: true }));
        this.notifications.set(updated);
        this.loadingMarkAll.set(false);
      },
      error: (err) => {
        console.error(err);
        this.loadingMarkAll.set(false);
      },
    });
  }

  markAsRead(id: string) {
    this.loadingSingle.update(ids => [...ids, id])
    this.api.markNotificationAsRead(id).subscribe({
      next: () => {
        const updated = this.notifications().map((n) => (n._id === id ? { ...n, seen: true } : n));

        this.notifications.set(updated);
        this.loadingSingle.update(ids => ids.filter(x => x !== id));
      },
      error: (err) => {
        console.error(err);
        this.loadingSingle.update(ids => ids.filter(x => x !== id));
      },
    });
  }

  clear() {
    this.notifications.set([]);
  }
}
