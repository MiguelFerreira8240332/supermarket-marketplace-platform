import { Injectable, signal } from '@angular/core';
import { ApiService } from '../api.service';
import { Favorite } from '../models/favorite.model';
import { Product } from '../models/product.model';
import { Supermarket } from '../models/supermarket.model';

@Injectable({ providedIn: 'root' })
export class FavoriteService {
  favouriteProducts = signal<Product[]>([]);
  favouriteSupermarkets = signal<Supermarket[]>([]);

  constructor(private api: ApiService) {}

  loadFavorites() {
    const token = localStorage.getItem('token');

    if (!token) {
      return;
    }

    this.api.getFavorites().subscribe((recivedData: Favorite) => {
      this.favouriteProducts.set(recivedData.products);
      this.favouriteSupermarkets.set(recivedData.supermarkets);
    });
  }

  isProductFavorite(productId: string): boolean {
    return this.favouriteProducts().some((product) => product._id === productId);
  }

  toggleProductFavorite(product: Product): void {
    if (this.isProductFavorite(product._id)) {
      this.api.removeFavorite(product._id).subscribe({
        next: () => {
          this.favouriteProducts.update((currentList) =>
            currentList.filter((item) => item._id !== product._id),
          );
        },
        error: (err) => console.error('Erro ao remover produto dos favoritos:', err),
      });
    } else {
      this.api.addFavorite(product._id).subscribe({
        next: () => {
          this.favouriteProducts.update((currentList) => [...currentList, product]);
        },
        error: (err) => console.error('Erro ao adicionar produto aos favoritos:', err),
      });
    }
  }

  isSupermarketFavorite(supermarketId: string): boolean {
    return this.favouriteSupermarkets().some((supermarket) => supermarket._id === supermarketId);
  }

  toggleSupermarketFavorite(supermarket: Supermarket): void {
    if (this.isSupermarketFavorite(supermarket._id)) {
      this.api.removeFavoriteSupermarket(supermarket._id).subscribe({
        next: () => {
          this.favouriteSupermarkets.update((currentList) =>
            currentList.filter((item) => item._id !== supermarket._id),
          );
        },
        error: (err) => console.error('Erro ao remover supermercado:', err),
      });
    } else {
      this.api.addFavoriteSupermarket(supermarket._id).subscribe({
        next: () => {
          this.favouriteSupermarkets.update((currentList) => [...currentList, supermarket]);
        },
        error: (err) => console.error('Erro ao adicionar supermercado:', err),
      });
    }
  }
}
