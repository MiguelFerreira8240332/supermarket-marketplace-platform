// services/auth.service.ts

import { Injectable } from '@angular/core';
import { ApiService } from '../api.service';
import { NotificationService } from './notification/notifcation.service';

@Injectable({ providedIn: 'root' })

export class AuthService {

  constructor(private api: ApiService, private notificationService: NotificationService) {}

  login(email: string, password: string) {
    return this.api.postAuthLogin(email, password);
  }
  register(data: any) {
    return this.api.postAuthRegister(data);
  }

  me() {
    return this.api.getAuthMe();
  }

  redirectAfterLogin(role: string) {
    if (role !== 'client') return false;
    this.api.navigate('/');
    return true;
  }

  saveToken(token: string) {
    localStorage.setItem('token', token);
  }

  saveUser(user: any) {
    localStorage.setItem('user', JSON.stringify(user));
  }

  getUser() {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
  }

  getToken() {
    return localStorage.getItem('token');
  }

  isClient() {
    return this.getUser()?.role === 'client';
  }

  
  logout() {
    this.notificationService.clear();
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    this.api.navigate('/');
  }

  isLoggedIn() {
    return !!this.getToken();
  }
}