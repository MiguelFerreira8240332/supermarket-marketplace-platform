// app.routes.ts

import { Routes } from '@angular/router';
import { AuthComponent } from './pages/auth/auth.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { LayoutComponent } from './components/layout/layout.component';
import { AuthGuard } from './guards/auth-guard';

export const routes: Routes = [
  { path: 'auth/login', component: AuthComponent },

  { path: '', component: LayoutComponent, children: [
    { path: '', component: DashboardComponent },

     { path: 'map', loadComponent: () => 
        import ('./components/map/map.component').then(map => map.MapComponent)   
      },

    { path: 'supermarkets', loadComponent: () =>
       import('./pages/supermarkets/supermarkets.component').then(m => m.SupermarketsComponent) 
    },

    { path: 'supermarkets/:id', loadComponent: () => 
      import('./pages/supermarkets/supermarket-details/supermarket-details.component').then(m => m.SupermarketComponent)
    },

    { path: 'cart', canActivate: [AuthGuard], loadComponent: () =>
       import('./pages/cart/cart.component').then(m => m.CartComponent) 
    },

    { path: 'orders', canActivate: [AuthGuard], loadComponent: () => 
      import('./pages/orders/orders.component').then(m => m.OrdersComponent) 
    },

    { path: 'order-history', canActivate: [AuthGuard], loadComponent: () => 
      import('./pages/order-history/order-history.component').then(m => m.OrderHistoryComponent) 
    },

    { path: 'account', canActivate: [AuthGuard], loadComponent: () => 
      import('./pages/account/account.component').then(m => m.AccountComponent) 
    },

      { path: 'products', loadComponent: () => 
      import('./pages/products/product-search/product-search.component').then(m => m.ProductSearchComponent)
    },

    { path: 'favourites', loadComponent: () => 
      import('./pages/favourites/favourites').then(m => m.FavouritesComponent)
    },

  ]},

 

  { path: '**', redirectTo: '' }
];