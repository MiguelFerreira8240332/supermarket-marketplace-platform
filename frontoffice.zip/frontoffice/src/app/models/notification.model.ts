// models/notitifcation.model.ts

export interface Notification {
    _id: string;
    user: string;
    title: string;
    message: string;
    seen: boolean;
    createdAt: string;
}