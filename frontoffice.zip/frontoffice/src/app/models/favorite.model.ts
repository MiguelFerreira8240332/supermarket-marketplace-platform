// models/favorite.model.ts

import { Product } from "./product.model";
import { Supermarket } from "./supermarket.model";

export interface Favorite {
    _id: string;
    user: string; // ObjectId do user
    products: Product[]; 
    supermarkets: Supermarket[]; 
    createdAt?: Date;
}