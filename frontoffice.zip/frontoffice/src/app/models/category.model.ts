// models/category.model.ts

export interface Category {
    _id: string;
    name: string;
    createdAt?: Date;
    updatedAt?: Date;
}