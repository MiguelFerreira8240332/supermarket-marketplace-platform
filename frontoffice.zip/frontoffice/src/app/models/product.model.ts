// models/product.model.ts

export interface Product {
    _id: string;
    name: string;
    description: string;
    price: number;
    stock: number;
    image: string;
    category: { _id: string; name: string };
    supermarket: { _id: string; name: string } | null;
    active: boolean;
    createdAt?: Date;
    updatedAt?: Date;
}