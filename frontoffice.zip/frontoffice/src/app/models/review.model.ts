export interface Review {
    _id: string;
    order: string;
    client: {
        _id: string;
        name: string;
    };
    supermarket: string;
    courier: string | null;
    supermarketRating: number | null;
    supermarketComment: string | null;
    courierRating: number | null;
    courierComment: string | null;
    createdAt: string;
}