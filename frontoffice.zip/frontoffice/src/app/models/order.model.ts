// models/order.model.ts

export interface Order {
    _id: string;
    supermarket: { _id: string; name: string; image: string };
    products: { 
        productId: { _id: string; name: string; image: string } | string; 
        amount: number; 
        price: number 
    }[];
    orderDate: Date;
    confirmationDate?: Date;
    deliveryDate?: Date;
    totalValue: number;
    deliveryCost: number;
    deliveryMethod: string;
    status: string;
    hasReview?: boolean;
}