// models/user.model.ts

export interface User {
    _id: string;
    name: string;
    email: string;
    password: string;
    address: string;
    phoneNumber: string;
    role: 'client' | 'supermarket' | 'courier' | 'admin';
    createdAt?: Date;
    updatedAt?: Date;
}
