/* models/supermarket.model.ts */

export interface Supermarket {
    _id: string;
    name: string;
    description: string;
    image: string;
    openingHours: string;
    deliveryMethods: string[];
    deliveryCosts: {
        pickup: number;
        courier: number;
    };
    location: {
        coordinates: number[];
        address: string;
    };
    isApproved: boolean;
}