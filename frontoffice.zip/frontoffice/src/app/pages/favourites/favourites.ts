import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FavoriteService } from '../../services/favorite.service';
import { ProductService } from '../../services/product.service';
import { CartService } from '../../services/cart.service';
import { ProductDetailsComponent } from '../products/product-details/product-details.component';
import { Product } from '../../models/product.model';
import { ApiService } from '../../api.service';

@Component({
  selector: 'app-favourites',
  standalone: true,
  imports: [CommonModule, FormsModule, ProductDetailsComponent],
  templateUrl: './favourites.html',
  styleUrls: ['./favourites.css'],
})
export class FavouritesComponent implements OnInit {
  activeWindow = signal<'produtos' | 'supermercados'>('produtos');
  selectedCategory = signal<string>('todos');

  constructor(
    public favoriteService: FavoriteService,
    public productService: ProductService,
    public cartService: CartService,
    public api: ApiService
  ) {}

  ngOnInit(): void {
    this.favoriteService.loadFavorites();
    this.productService.loadCategories();
  }

  changeWindow(aba: 'produtos' | 'supermercados'): void {
    this.activeWindow.set(aba);
    this.selectedCategory.set('todos');
  }

  addProduct(product: any): void {
    this.cartService.message.set('');
    this.cartService.addToCart(product);
  }

  abrirModal(produto: Product) {
    this.productService.abrirModal(produto);
  }

 abrirSupermercado(market: any) {
    this.api.navigate('/supermarkets/' + market._id);
  }
}
