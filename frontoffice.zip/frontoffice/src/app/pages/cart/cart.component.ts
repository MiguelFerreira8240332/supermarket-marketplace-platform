import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { CartService } from '../../services/cart.service';
import { ApiService } from '../../api.service';
import { Router } from '@angular/router';
import { StateLoadingComponent } from '../../utils/state-loading/state-loading.component';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { LoginDialog } from '../../components/login-dialog/login-dialog';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule, FormsModule, StateLoadingComponent, MatDialogModule],
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css',
})
export class CartComponent {
  deliveryMethod = '';
  loading = signal<boolean>(false);
  error = signal<string>('');

  constructor(
    public cartService: CartService,
    private api: ApiService,
    private router: Router,
    private dialog: MatDialog,
  ) {}

  get supermarket() {
    const items = this.cartService.items();
    return items.length > 0 ? items[0].supermarket : null;
  }

  get deliveryMethods() {
    return this.supermarket?.deliveryMethods || [];
  }

  get deliveryCost() {
    if (!this.supermarket || !this.deliveryMethod) {
      return 0;
    }

    if (this.deliveryMethod === 'entrega por estafeta') {
      return this.supermarket.deliveryCosts?.courier || 0;
    }

    return this.supermarket.deliveryCosts?.pickup || 0;
  }

  get totalWithDelivery() {
    return this.cartService.total() + this.deliveryCost;
  }

  checkout() {
    const token = localStorage.getItem('token');

    if (!token) {
      const dialogRef = this.dialog.open(LoginDialog, {
        width: '400px'
      });

      dialogRef.afterClosed().subscribe((redirectToLogin) => {
        if (redirectToLogin) {
          this.router.navigate(['/auth/login']);
        }
      });
      return;
    }

    if (!this.deliveryMethod) {
      this.error.set('Escolhe um método de entrega');
      return;
    }

    this.loading.set(true);
    this.error.set('');

    const body = {
      supermarket: this.supermarket._id,
      deliveryMethod: this.deliveryMethod,
      products: this.cartService.items().map((item) => ({
        productId: item._id,
        amount: item.quantity,
      })),
    };

    this.api.createOrder(body).subscribe({
      next: (res: any) => {
          this.cartService.clearCart();
          this.cartService.closeCart();
          this.router.navigate(['/order-history'], { queryParams: { order: res._id } });
      },
      error: (err) => {
          this.error = err.error?.error || 'Erro ao criar encomenda.';
          this.loading.set(false);
      }
    });
  }
}
