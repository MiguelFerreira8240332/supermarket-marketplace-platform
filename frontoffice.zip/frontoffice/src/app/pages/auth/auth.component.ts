  // pages/auth/auth.component.

  import { Component, signal } from '@angular/core';
  import { AuthService } from '../../services/auth.service';
  import { FormsModule } from '@angular/forms';
  import { CommonModule } from '@angular/common';

  @Component({
    selector: 'app-auth',
    standalone: true,
    imports: [FormsModule, CommonModule],
    templateUrl: './auth.component.html',
    styleUrl: './auth.component.css',
  })
  export class AuthComponent {
    isLogin = true;
    email = '';
    password = '';
    name = '';
    registerEmail = '';
    registerPassword = '';
    address = '';
    phoneNumber = '';
    loading = signal(false);
    showBackofficeLink = signal(false);
    error = signal('');
    success = signal('');
    passwordFocused = signal(false);

    constructor(private authService: AuthService) {}

    onLogin() {
      this.error.set('');
      this.showBackofficeLink.set(false);
      this.loading.set(true);
      this.authService.login(this.email, this.password).subscribe({
        next: (res: any) => {
          if (res.user.role !== 'client') {
            this.showBackofficeLink.set(true);
            this.loading.set(false);
            return;
          }
          this.authService.saveToken(res.token);
          this.authService.saveUser(res.user);
          this.loading.set(false);
          this.authService.redirectAfterLogin(res.user.role);
        },
        error: (err) => {
          this.error.set(err.error?.error || 'Erro no login');
          this.loading.set(false);
        }
      });
    }

    onRegister() {
      this.error.set('');
      this.success.set('');
      this.loading.set(true);
      this.authService.register({
        name: this.name,
        email: this.registerEmail,
        password: this.registerPassword,
        address: this.address,
        phoneNumber: this.phoneNumber
      }).subscribe({
        next: () => {
          this.success.set('Conta criada! Podes fazer login agora.');
          this.isLogin = true;
          this.loading.set(false);
        },
        error: (err) => {
          this.error.set(err.error?.error || 'Erro no registo');
          this.loading.set(false);
        }
      });
    }
  }