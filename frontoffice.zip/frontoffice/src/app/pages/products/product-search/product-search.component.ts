// pages/product-search/product-search.component.ts

import { Component, OnInit, input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../../../services/product.service';
import { CartService } from '../../../services/cart.service';
import { Product } from '../../../models/product.model';
import { LoadMoreBtnComponent } from '../../../utils/load-more-btn/load-more-btn.component';
import { ProductDetailsComponent } from '../product-details/product-details.component';
import { FavoriteService } from '../../../services/favorite.service';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { LoginDialog } from '../../../components/login-dialog/login-dialog';
import { ApiService } from '../../../api.service';
import { SortBtnComponent } from '../../../components/sort-btn/sort-btn.component';
import { StateLoadingComponent } from '../../../utils/state-loading/state-loading.component';

@Component({
  selector: 'app-products',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    LoadMoreBtnComponent,
    SortBtnComponent,
    StateLoadingComponent,
    ProductDetailsComponent,
    MatDialogModule,
  ],
  templateUrl: './product-search.component.html',
  styleUrls: ['./product-search.component.css'],
})
export class ProductSearchComponent implements OnInit {
  showCartButton = input<boolean>(true);
  hideMarketFilter = input<boolean>(false);
  supermarketId = input<string>('');

  searchProduct: string = '';
  selectCategory: string = '';
  selectSupermarket: string = '';
  selectedSupermarketLabel: string = 'Supermercados';

  constructor(
    public productService: ProductService,
    public cartService: CartService,
    public favoriteService: FavoriteService,
    private dialog: MatDialog,
    public api: ApiService,
  ) {}

  ngOnInit() {
    this.cartService.message.set('');
    this.cartService.messageProductId.set('');
    this.favoriteService.loadFavorites();
    this.selectSupermarket = this.supermarketId();
    this.productService.loadCategories();
    this.productService.loadSupermarkets();
    this.atualizarLista();
  }

  atualizarLista() {
    this.productService.loadProducts(
      this.searchProduct,
      this.selectCategory,
      this.selectSupermarket,
    );
  }

  loadMore() {
    this.productService.loadMore(this.searchProduct, this.selectCategory, this.selectSupermarket);
  }

  setSupermarket(id: string) {
    this.selectSupermarket = id;

    const market = this.productService.supermarkets().find((s) => s._id === id);

    this.selectedSupermarketLabel = market?.name || 'Todos os supermercados';

    this.atualizarLista();
  }

  abrirModal(produto: Product) {
    this.productService.abrirModal(produto);
  }

  addToFavorites(product: any): void {
    const token = localStorage.getItem('token');
    if (!token) {
      const dialogRef = this.dialog.open(LoginDialog, { width: '400px' });

      dialogRef.afterClosed().subscribe((redirectToLogin) => {
        if (redirectToLogin) {
          this.api.navigate('/auth/login');
        }
      });

      return;
    }

    this.favoriteService.toggleProductFavorite(product);
  }
}
