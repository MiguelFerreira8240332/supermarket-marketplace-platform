// pages/products/product-details/product-details.component.ts

import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CartService } from '../../../services/cart.service';
import { ProductService } from '../../../services/product.service';
import { SortBtnComponent } from '../../../components/sort-btn/sort-btn.component';
import { StateLoadingComponent } from '../../../utils/state-loading/state-loading.component';

@Component({
  selector: 'app-product-details',
  standalone: true,
  imports: [CommonModule, SortBtnComponent, StateLoadingComponent],
  templateUrl: './product-details.component.html',
  styleUrl: './product-details.component.css'
})
export class ProductDetailsComponent {
  @Input() product: any;
  @Input() showCartButton = false;

  constructor(
    public cartService: CartService,
    public productService: ProductService
  ) {
    this.cartService.message.set('');
  }

  adicionar(product: any) {
    this.cartService.addToCart(product);
  }

  fecharModal() {
    this.cartService.message.set('');
    this.productService.selectedProduct.set(null);
  }

}