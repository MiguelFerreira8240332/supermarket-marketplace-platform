// pages/order-history/order-history.component.ts

import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../api.service';
import { Order } from '../../models/order.model';
import { LoadMoreBtnComponent } from '../../utils/load-more-btn/load-more-btn.component';
import { HeroBannerComponent } from '../../components/hero-banner/hero-banner.component';
import { StateLoadingComponent } from '../../utils/state-loading/state-loading.component';
import { OrderDetailsComponent } from '../orders/order-details/order-details.component';
import { ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { ReviewFormDialogComponent } from '../../components/reviews/review-form-dialog/review-form-dialog.component';

@Component({
  selector: 'app-order-history',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    OrderDetailsComponent,
    LoadMoreBtnComponent,
    HeroBannerComponent,
    StateLoadingComponent,
  ],
  templateUrl: './order-history.component.html',
  styleUrl: './order-history.component.css',
})
export class OrderHistoryComponent implements OnInit {
  ongoing = signal<Order[]>([]);
  finished = signal<Order[]>([]);
  activeTab = 'ongoing';
  selectedOrder = signal<Order | null>(null);
  loading = signal<boolean>(false);
  dateFrom = '';
  dateTo = '';
  statusFilter = signal<string>('');
  visibleCount = signal(10);

  constructor(
    private api: ApiService,
    private route: ActivatedRoute,
    private dialog: MatDialog,
  ) {}

  ngOnInit() {
    this.loadOngoing();
    this.loadFinished();
  }

  loadOngoing() {
    this.loading.set(true);
    this.api.getOngoingOrders().subscribe((data: Order[]) => {
      this.ongoing.set(data);
      const orderId = this.route.snapshot.queryParamMap.get('order');
      if (orderId) {
        const found = data.find((o) => o._id === orderId);
        if (found) {
          this.selectedOrder.set(found);
          this.activeTab = 'ongoing';
        }
      }
      this.loading.set(false);
    });
  }

  loadFinished() {
  this.loading.set(true);

    this.api.getFinishedOrders().subscribe((data: Order[]) => {
      this.finished.set(data);
      this.loading.set(false);
    });
  }

  loadMore() {
    this.visibleCount.update((v) => v + 10);
  }

  get visibleOrders() {
  if (this.activeTab === 'ongoing') {
    return this.ongoing();
  }

  return this.finished()
    .filter((o) => {
        if (this.statusFilter() && o.status !== this.statusFilter()) {
          return false;
        }
        if (this.dateFrom && new Date(o.orderDate) < new Date(this.dateFrom)) {
          return false;
        }
        if (this.dateTo && new Date(o.orderDate) > new Date(this.dateTo)) {
          return false;
        }
        return true;
      })
    .slice(0, this.visibleCount());
  }

  selectOrder(order: Order) {
    this.selectedOrder.set(this.selectedOrder()?._id === order._id ? null : order);
  }

  onCancelled(orderId: string) {
    this.ongoing.update((orders) =>
      orders.map((o) => (o._id === orderId ? { ...o, status: 'Cancelada' } : o)),
    );
    this.selectedOrder.set(null);
  }

  getStatusClass(status: string) {
    const map: any = {
      Pendente: 'warning',
      Confirmada: 'info',
      'Em processamento': 'primary',
      'Em entrega': 'primary',
      Entregue: 'success',
      Cancelada: 'danger',
    };
    return map[status] || 'secondary';
  }

  openReviewDialog(order: Order) {
    const dialogRef = this.dialog.open(ReviewFormDialogComponent, {
      width: '500px',
      data: { order },
    });

    dialogRef.afterClosed().subscribe((success) => {
      if (success) {
        order.hasReview = true;
      }
    });
  }

  get hasMore() {
    return this.visibleOrders.length < this.finished().filter((o) => {
      if (this.statusFilter() && o.status !== this.statusFilter()) {
        return false;
      }
      if (this.dateFrom && new Date(o.orderDate) < new Date(this.dateFrom)) {
        return false;
      }
      if (this.dateTo && new Date(o.orderDate) > new Date(this.dateTo)) {
        return false;
      }
      return true;
    }).length;
  }
    
}
