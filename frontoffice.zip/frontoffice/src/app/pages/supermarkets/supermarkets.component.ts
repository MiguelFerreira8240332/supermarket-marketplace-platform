import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../../services/product.service';
import { MapComponent } from '../../components/map/map.component';
import { RouterLink } from '@angular/router';
import { GeolocationService } from '../../utils/geo-location/geolocation.service';
import { FavoriteService } from '../../services/favorite.service'; 
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { LoginDialog } from '../../components/login-dialog/login-dialog';
import { ApiService } from '../../api.service';

@Component({
  selector: 'app-supermarkets',
  standalone: true,
  imports: [CommonModule, FormsModule, MapComponent, RouterLink],
  templateUrl: './supermarkets.component.html',
  styleUrl: './supermarkets.component.css',
})
export class SupermarketsComponent implements OnInit {
  search = '';

  constructor(private geo: GeolocationService, public productService: ProductService, public favoriteService: FavoriteService, private dialog: MatDialog, public api: ApiService) {}

  ngOnInit() {
    window.scrollTo(0,0);
    this.productService.loadSupermarkets();
    this.favoriteService.loadFavorites();
    this.geo.getUserLocation();
  }

  get filtered() {
    return this.productService
      .supermarkets()
      .filter(
        (s) =>
          s.name.toLowerCase().includes(this.search.toLowerCase()) ||
          s.location?.address?.toLowerCase().includes(this.search.toLowerCase()),
      );
  }

  get mapMarkers() {
    const favs = this.favoriteService.favouriteSupermarkets();
    const coords = this.geo.coords();

    const markers = this.productService.supermarkets().map((s) => ({
      lat: s.location?.coordinates?.[1],
      lng: s.location?.coordinates?.[0],
      title: s.name,
      description: s.location?.address + '<br>' + s.openingHours + '<br>Envio: ' + s.deliveryCosts.courier + "€",
      icon: s.image ? 'http://localhost:3000/images/' + s.image : '',
      isFavorite: favs.some(market => market._id === s._id),
    }));

    if (coords) {
      markers.push({
        lat: coords.lat,
        lng: coords.lng,
        title: 'Tu estás aqui!',
        description: 'localização atual',
        icon: '📍',
        isFavorite: false,
      });
    }
    return markers;
  }

  addFavorite(supermarket: any) {
    const token = localStorage.getItem('token');
    if (!token) {
      const dialogRef = this.dialog.open(LoginDialog, {width: '400px'});

      dialogRef.afterClosed().subscribe((redirectToLogin) => {
        if (redirectToLogin) {
          this.api.navigate('/auth/login'); 
        }
      });
      
      return;
    }
    
    this.favoriteService.toggleSupermarketFavorite(supermarket);
  }
}
