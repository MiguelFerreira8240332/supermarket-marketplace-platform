import { Component, OnInit, signal } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { ApiService } from '../../../api.service';
import { ProductService } from '../../../services/product.service';
import { Supermarket } from '../../../models/supermarket.model';
import { CommonModule } from '@angular/common';
import { MapComponent } from '../../../components/map/map.component';
import { ProductSearchComponent } from '../../products/product-search/product-search.component';
import { GeolocationService } from '../../../utils/geo-location/geolocation.service';
import { FavoriteService } from '../../../services/favorite.service';
import { MatDialog } from '@angular/material/dialog';
import { ReviewDialogComponent } from '../../../components/reviews/review-dialog/review-dialog.component';
import { StateLoadingComponent } from '../../../utils/state-loading/state-loading.component';
import { Review } from '../../../models/review.model';

@Component({
  selector: 'app-supermarket',
  standalone: true,
  imports: [CommonModule, MapComponent, ProductSearchComponent, RouterLink, StateLoadingComponent],
  templateUrl: './supermarket-details.component.html',
  styleUrl: './supermarket-details.component.css',
})
export class SupermarketComponent implements OnInit {
  supermarket = signal<Supermarket | null>(null);
  reviews = signal<Review[]>([]);
  averageRating = signal(0);
  loading = signal(true);

  constructor(private route: ActivatedRoute, private api: ApiService, private geo: GeolocationService, public productService: ProductService, public favoriteService: FavoriteService, private dialog: MatDialog,) {}

  ngOnInit() {
    window.scrollTo(0, 0);

    const id = this.route.snapshot.paramMap.get('id');

    if (id) {
      this.loading.set(true);
      this.api.getSupermarketById(id).subscribe({
        next: (market: Supermarket) => {
          this.supermarket.set(market);
          this.api.getSupermarketReviews(id).subscribe({
            next: (reviews) => {
              this.reviews.set(reviews);
              if (reviews.length > 0) {
                let total = 0;
                for (const review of reviews) {
                    total += review.supermarketRating ?? 0;
                }
                this.averageRating.set(Number((total / reviews.length).toFixed(1)));
              }
              this.loading.set(false);
            },
            error: () => {
              this.loading.set(false);
            },
          });
        },
        error: () => {
          this.loading.set(false);
        },
      });
      this.favoriteService.loadFavorites();
    }
  }

  get mapMarkers() {
    const s = this.supermarket();
    if (!s) return [];
    return [
      {
        lat: s.location?.coordinates?.[1],
        lng: s.location?.coordinates?.[0],
        title: s.name,
        description: s.location?.address,
        icon: s.image ? 'http://localhost:3000/images/' + s.image : '',
        isFavorite: false,
      },
    ];
  }

  toggleFavorite() {
    const s = this.supermarket();
    if (s) {
      this.favoriteService.toggleSupermarketFavorite(s);
    }
  }


  get hasValidLocation() {
    const s = this.supermarket();
    if (!s?.location?.coordinates) return false;
    const [lng, lat] = s.location.coordinates;
    return !(lat === 0 && lng === 0);
  }

  openReviews() {
    this.dialog.open(ReviewDialogComponent, {
      width: '700px',
      data: { reviews: this.reviews() },
    });
  }
}
