import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SupermarketComponent } from './supermarket-details.component';

describe('SupermarketComponent', () => {
  let component: SupermarketComponent;
  let fixture: ComponentFixture<SupermarketComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SupermarketComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(SupermarketComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
