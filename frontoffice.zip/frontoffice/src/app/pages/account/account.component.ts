// pages/account/account.component.ts

import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { ApiService } from '../../api.service';
import { User } from '../../models/user.model';
import { HeroBannerComponent } from '../../components/hero-banner/hero-banner.component';
import { NotificationComponent } from '../../components/notification/notification.component';
import { NotificationService } from '../../services/notification/notifcation.service';
import { AccountStatsComponent } from '../../components/account/account-stats/account-stats.component';
import { AccountProfileComponent } from '../../components/account/account-profile/account-profile.component';

@Component({
  selector: 'app-account',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterLink,
    HeroBannerComponent,
    NotificationComponent,
    AccountStatsComponent,
    AccountProfileComponent,
  ],
  templateUrl: './account.component.html',
  styleUrl: './account.component.css',
})

export class AccountComponent implements OnInit {
  user = signal<User | null>(null);
  showNotifications = signal(false);

  constructor(
    private api: ApiService,
    public authService: AuthService,
    public notificationService: NotificationService,
  ) {}

  ngOnInit() {
    this.user.set(this.authService.getUser());

    this.notificationService.loadNotifications();
  }

  toggleNotifications() {
    this.showNotifications.update((v) => !v);
  }

  logout() {
    this.authService.logout();
  }
}
