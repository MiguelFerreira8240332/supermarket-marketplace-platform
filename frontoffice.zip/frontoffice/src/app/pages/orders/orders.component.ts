// pages/orders/order.component.ts

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Router } from '@angular/router';

import { ProductSearchComponent } from '../products/product-search/product-search.component';
import { CartComponent } from '../cart/cart.component';

import { AuthService } from '../../services/auth.service';
import { CartService } from '../../services/cart.service';

@Component({
  selector: 'app-orders',
  standalone: true,
  imports: [CommonModule, ProductSearchComponent, CartComponent],
  templateUrl: './orders.component.html',
  styleUrl: './orders.component.css'
})
export class OrdersComponent implements OnInit {

 constructor(private router: Router, private authService: AuthService, public cartService: CartService) {}

  ngOnInit() {

    if (!this.authService.isLoggedIn()) {
      this.router.navigate(['/auth/login']);
    }
  }
}