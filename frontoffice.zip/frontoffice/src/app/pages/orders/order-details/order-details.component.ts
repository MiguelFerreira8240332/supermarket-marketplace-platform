// pages/orders/order/order.component.ts

import { Component, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Order } from '../../../models/order.model';
import { ApiService } from '../../../api.service';

@Component({
  selector: 'app-order-details',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './order-details.component.html',
  styleUrl: './order-details.component.css'
})
export class OrderDetailsComponent {
  order = input.required<Order>();
  cancelled = output<string>();


  constructor(private api: ApiService) {}

  getProductName(item: any) {
    return typeof item.productId === 'object' ? item.productId.name : 'Produto';
  }

   canCancel() {
    const status = this.order().status;
    return status === 'Pendente' || status === 'Confirmada';
  }

  cancel() {
    this.api.cancelOrder(this.order()._id).subscribe({
      next: () => this.cancelled.emit(this.order()._id),
      error: (err) => alert(err.error?.error || 'Erro ao cancelar')
    });
  }
  
  pay() {
    this.api.createPayment(this.order()._id).subscribe({
        next: (res) => window.location.href = res.url,
        error: (err) => alert(err.error?.error || 'Erro ao processar pagamento')
    });
}
}