// pages/dashboard/dashboard.component.ts

import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { ProductSearchComponent } from '../products/product-search/product-search.component';
import { ProductService } from '../../services/product.service';
import { AuthService } from '../../services/auth.service';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, ProductSearchComponent, RouterLink, NgOptimizedImage],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, OnDestroy {
  hasVisited = false;
  
  constructor(private router: Router, public productService: ProductService, public authService: AuthService) {}

  ngOnInit() {
    if (sessionStorage.getItem('hasVisited') === 'true') {
      this.hasVisited = true;
    }

    this.productService.loadSupermarkets();

    const wrapper = document.querySelector('.products-wrapper');
    const wrapperCategory = document.querySelector('.categories-wrapper');
    if (wrapper) wrapper.scrollTop = 0;
    if (wrapperCategory) wrapperCategory.scrollLeft = 0; 
  }


  ngOnDestroy() {
    sessionStorage.setItem('hasVisited', 'true');
  }

  markAsVisited() {
    sessionStorage.setItem('hasVisited', 'true');
    this.hasVisited = true; 
  }

  getFeatured() {
    const cached = sessionStorage.getItem('featuredSupermarkets');
    if (cached) return JSON.parse(cached);
    return this.productService.supermarkets().slice(0, 4);
  }

  goTo(path: string) {
    this.markAsVisited();
    this.router.navigate([path]);
  }

scrollToProducts() {
  const element = document.getElementById('products');
  if (!element) return;
  const offset = 58;
  const top =
    element.getBoundingClientRect().top +
    window.scrollY -
    offset;

  window.scrollTo({
    top, behavior: 'smooth'
  });
}

}