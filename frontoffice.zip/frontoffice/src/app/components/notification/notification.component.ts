import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NotificationService } from '../../services/notification/notifcation.service';
import { StateLoadingComponent } from '../../utils/state-loading/state-loading.component';

@Component({
  selector: 'app-notification',
  standalone: true,
  imports: [CommonModule, StateLoadingComponent],
  templateUrl: './notification.component.html',
  styleUrl: './notification.component.css'
})

export class NotificationComponent implements OnInit {

  constructor(public notificationService: NotificationService) {}

  ngOnInit() {
    this.notificationService.loadNotifications();
  }
  

}