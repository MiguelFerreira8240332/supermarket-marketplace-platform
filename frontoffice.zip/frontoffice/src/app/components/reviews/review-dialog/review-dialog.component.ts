// components/reviews/review-dialog/review-dialog.component.ts

import { Component, inject } from '@angular/core';

import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';

import { ReviewsListComponent } from '../reviews-list/reviews-list.component';

@Component({
  selector: 'app-review-dialog',
  standalone: true,
  imports: [MatDialogModule, ReviewsListComponent],
  templateUrl: './review-dialog.component.html',
  styleUrl: './review-dialog.component.css',
})
export class ReviewDialogComponent {
  data = inject(MAT_DIALOG_DATA);
}
