// components/review/review-form-dialog/review-form-dialog.component.ts

import { Component, inject, signal } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { ApiService } from '../../../api.service';
import { StateLoadingComponent } from '../../../utils/state-loading/state-loading.component';

@Component({
  selector: 'app-review-form-dialog',
  standalone: true,
  imports: [CommonModule, FormsModule, MatDialogModule, MatButtonModule, MatInputModule, StateLoadingComponent],
  templateUrl: './review-form-dialog.component.html',
  styleUrl: './review-form-dialog.component.css',
})
export class ReviewFormDialogComponent {
  data = inject(MAT_DIALOG_DATA);
  dialogRef = inject(MatDialogRef<ReviewFormDialogComponent>);
  supermarketRating = signal<number | null>(null);
  courierRating = signal<number | null>(null);
  supermarketComment = signal('');
  courierComment = signal('');
  error = signal('');
  loading = signal(false);

  constructor(private api: ApiService) {}

  submit() {
    this.loading.set(true);
    this.error.set('');
    const data: any = { orderId: this.data.order._id, };

    if (this.supermarketRating()) {
      data.supermarketRating = this.supermarketRating();
      data.supermarketComment = this.supermarketComment();
    }

    if (this.data.order.deliveryMethod === 'Entrega ao domicilio' && this.courierRating()) {
      data.courierRating = this.courierRating();
      data.courierComment = this.courierComment();
    }

    this.api.createReview(data).subscribe({
      next: () => {
        this.loading.set(false);
        this.dialogRef.close(true);
      },

      error: (err) => {
        this.loading.set(false);
        this.error.set(err.error?.error ||'Erro ao enviar avaliação');
      },
    });
  }
}
