// components/reviews-list/reviews-list.component.ts

import { Component, computed, input, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { Review } from '../../../models/review.model';

@Component({
  selector: 'app-reviews-list',
  standalone: true,
  imports: [CommonModule, MatCardModule, MatPaginatorModule],
  templateUrl: './reviews-list.component.html',
  styleUrl: './reviews-list.component.css',
})

export class ReviewsListComponent {
  reviews = input<Review[]>([]);
  pageSize = 5;
  currentPage = signal(0);

  paginatedReviews = computed(() => {
    const start = this.currentPage() * this.pageSize;

    const end = start + this.pageSize;

    return this.reviews().slice(start, end);
  });

  onPageChange(event: PageEvent) {
    this.currentPage.set(event.pageIndex);
  }
}
