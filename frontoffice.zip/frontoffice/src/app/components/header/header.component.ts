// components/header/header.component.ts

import { Component, HostListener, OnInit, signal } from '@angular/core';
import { Router, RouterLink} from '@angular/router';
import { CartService } from '../../services/cart.service';
import { NotificationService } from '../../services/notification/notifcation.service';
import { ColorThemeService } from '../../services/themes/color-theme.service';
import { ApiService } from '../../api.service';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { LoginDialog } from '../../components/login-dialog/login-dialog';
import { FavoriteService } from '../../services/favorite.service';
import { CartComponent } from '../../pages/cart/cart.component';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [RouterLink, CartComponent],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css',
})
export class HeaderComponent implements OnInit{
  constructor(
    private router: Router, 
    public cartService: CartService, 
    public notificationService: NotificationService, 
    private api: ApiService,
    public theme: ColorThemeService,
    private dialog: MatDialog,
    public favoriteService: FavoriteService,
  ) {}

  ngOnInit(): void {
    this.notificationService.loadNotifications();
  }

  scrolled = false;

  @HostListener('window:scroll')

  onScroll() {
    this.scrolled = window.scrollY > 0;
  }

  get isOrdersPage(): boolean {
    return this.router.url.startsWith('/orders');
  }

  get firstVisit() {
    return (this.router.url === '/' && !this.scrolled
    );
  }

  get showCartButton() {
    return this.isMobile || this.router.url.includes('/orders');
  }

  get showShopButton() {
    return this.router.url !== '/' && this.router.url !== '/orders';
  }

  openFavoritesPage(): void {
      const token = localStorage.getItem('token');
      if (!token) {
        const dialogRef = this.dialog.open(LoginDialog, { width: '400px' });
  
        dialogRef.afterClosed().subscribe((redirectToLogin) => {
          if (redirectToLogin) {
            this.api.navigate('/auth/login');
          }
        });
      return;
    }
    this.api.navigate('/favourites');
  }

  get isMobile(): boolean {
    return window.innerWidth <= 848;
  }

  get shouldShowMobileCart(): boolean {
    return this.cartService.cartOpen() && this.isMobile;
  }
}



