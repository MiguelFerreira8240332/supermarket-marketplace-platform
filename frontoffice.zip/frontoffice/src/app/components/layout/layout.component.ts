import { Component, HostListener } from '@angular/core';
import { RouterOutlet, Router } from '@angular/router';
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [RouterOutlet, HeaderComponent, FooterComponent],
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css']
})
export class LayoutComponent {

constructor(private router: Router) {}

scrolled = false;

@HostListener('window:scroll')

onScroll() {
  this.scrolled = window.scrollY > 0;
}


get firstVisit() {
  return (this.router.url === '/' && !this.scrolled
  );
}
}