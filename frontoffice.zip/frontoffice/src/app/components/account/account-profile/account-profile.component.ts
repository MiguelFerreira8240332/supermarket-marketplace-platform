// component/account-profile/account-profile.component.ts

import { Component, input, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { User } from '../../../models/user.model';
import { ApiService } from '../../../api.service';
import { AuthService } from '../../../services/auth.service';

@Component({
  selector: 'app-account-profile',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './account-profile.component.html',
  styleUrl: './account-profile.component.css',
})
export class AccountProfileComponent {
  user = input<User | null>(null);
  editing = signal(false);
  message = signal('');
  loading = signal(false);

  constructor(
    private api: ApiService,
    private authService: AuthService,
  ) {}

  saveUser() {
    if (!this.editing()) {
      this.message.set('');
      this.editing.set(true);
      return;
    }

    const original = this.authService.getUser();
    const user = this.user()!;

    if (
      user.name === original.name &&
      user.email === original.email &&
      user.address === original.address &&
      user.phoneNumber === original.phoneNumber
    ) {
      this.editing.set(false);
      return;
    }

    this.loading.set(true);

    this.api
      .putUser(user._id, {
        name: user.name,
        email: user.email,
        address: user.address,
        phoneNumber: user.phoneNumber,
      })
      .subscribe({
        next: (res: any) => {
          this.authService.saveUser(res.user);
          this.loading.set(false);
          this.message.set(res.message || 'Perfil atualizado!');
          this.editing.set(false);
        },
        error: (err) => {
          this.loading.set(false);
          this.message.set(err.error?.error || 'Erro ao atualizar dados');
        },
      });
  }
}
