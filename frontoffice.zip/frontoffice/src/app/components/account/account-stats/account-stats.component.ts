 // component/account-stats/account-stats.component.ts
 
import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FavoriteService } from '../../../services/favorite.service';
import { ApiService } from '../../../api.service';
import { StateLoadingComponent } from '../../../utils/state-loading/state-loading.component';

@Component({
  selector: 'app-account-stats',
  standalone: true,
  imports: [CommonModule, StateLoadingComponent],
  templateUrl: './account-stats.component.html',
  styleUrl: './account-stats.component.css',
})
export class AccountStatsComponent implements OnInit {
  favouriteProductsCount = signal(0);
  favouriteSupermarketsCount = signal(0);
  ordersCount = signal(0);
  loading = signal(true);

  constructor(
    private favoriteService: FavoriteService,
    private api: ApiService
  ) {}

ngOnInit() {

  this.loading.set(true);

  this.api.getFavorites().subscribe({
    next: (favorites) => {

      this.favouriteProductsCount.set(
        favorites.products.length
      );

      this.favouriteSupermarketsCount.set(
        favorites.supermarkets.length
      );

      this.loading.set(false);
    },

    error: () => {
      this.loading.set(false);
    }
  });

  this.api.getOrdersCount().subscribe({
    next: (res) => {
      this.ordersCount.set(res.count);
    }
  });

}
}