import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountStatsComponent } from './account-stats.component';

describe('AccountStatsComponent', () => {
  let component: AccountStatsComponent;
  let fixture: ComponentFixture<AccountStatsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AccountStatsComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(AccountStatsComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
