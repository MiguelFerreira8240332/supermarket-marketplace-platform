// components/map/map.component.ts

import { Component, Input, AfterViewInit, OnChanges, input } from '@angular/core';

declare const L: any;

@Component({
  selector: 'app-map',
  standalone: true,
  imports: [],
  templateUrl: './map.component.html',
})
export class MapComponent implements AfterViewInit, OnChanges {
  markers = input<
    {
      lat: number;
      lng: number;
      title: string;
      description: string;
      icon: string;
      isFavorite?: boolean;
    }[]
  >([]);

  private map: any;
  private mapMarkers: any[] = [];

  private redIcon: any; 
  private greenIcon: any;

  ngAfterViewInit() {
    this.initMap();
  }

  ngOnChanges() {
    if (!this.map) return;
    this.clearMarkers();
    this.addMarkers();

    const user = this.markers().find((m) => m.icon === '📍');
    if (user) {
      this.map.setView([user.lat, user.lng], 10);
    } else if (this.markers().length == 1) {
        const first = this.markers()[0];
        this.map.setView([first.lat, first.lng], 12)
    }
  }

  private initMap() {
    this.map = L.map('map').setView([39.5, -8.0], 7);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap',
    }).addTo(this.map);
    this.redIcon = L.icon({
      iconUrl:'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png'
    });
    this.greenIcon = L.icon({
      iconUrl:'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-green.png'
    });

    if (this.markers().length > 0) {
      this.addMarkers();
    }
  }

  addMarkers() {
    this.markers().forEach((m) => {
      if (typeof m.lat === 'number' && typeof m.lng === 'number') {
        let config = {};

        if (m.icon === '📍') {
          config = { icon: this.redIcon };
        } else if (m.isFavorite) {
          config = { icon: this.greenIcon };

        }
        const marker = L.marker([m.lat, m.lng], config).addTo(this.map);

        marker.bindPopup(`
        <div style="text-align: center">
          ${m.icon !== '📍' ? `<img src="${m.icon}" style="width:100px; border-radius:8px">` : ''}
          <br><b>${m.title}</b>
          <br>${m.description}
        </div>
      `);

        this.mapMarkers.push(marker);
      }
    });
  }

  clearMarkers() {
    this.mapMarkers.forEach((m) => this.map.removeLayer(m));
    this.mapMarkers = [];
  }
}
