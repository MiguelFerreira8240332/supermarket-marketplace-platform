import { Component, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-sort-btn',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './sort-btn.component.html',
  styleUrls: ['./sort-btn.component.css']
})
export class SortBtnComponent {
  sorted = output<boolean>();
  label = input<string>('Preço');

  sortAsc = true;

  toggleSort() {
    this.sortAsc = !this.sortAsc;
    this.sorted.emit(this.sortAsc);
  }
}