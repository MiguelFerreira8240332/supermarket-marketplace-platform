import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SortBtnComponent } from './sort-btn.component';

describe('SortBtnComponent', () => {
  let component: SortBtnComponent;
  let fixture: ComponentFixture<SortBtnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SortBtnComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(SortBtnComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
