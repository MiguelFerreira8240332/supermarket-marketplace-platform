// utils/state-loading/state-loading.component.ts

import { Component, input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatProgressSpinnerModule }from '@angular/material/progress-spinner';

@Component({
  selector: 'app-state-loading',
  standalone: true,
  imports: [CommonModule, MatProgressSpinnerModule],
  templateUrl: './state-loading.component.html',
  styleUrl: './state-loading.component.css',
})
export class StateLoadingComponent {
  loading =  input<boolean>(false);
  inline = input<boolean>(false);
  diameter = input<number>(80);
}