import { Injectable, signal } from '@angular/core';

@Injectable({ providedIn: 'root' })

export class GeolocationService {
    coords = signal<{ lat: number; lng: number } | null>(null);

    getUserLocation() {
        if (!navigator.geolocation) return;
        navigator.geolocation.getCurrentPosition(
            (pos) => {
                this.coords.set({
                    lat: pos.coords.latitude,
                    lng: pos.coords.longitude
                });
            },
            (err) => console.log('Erro:', err),
            { enableHighAccuracy: false }
        );
    }
}