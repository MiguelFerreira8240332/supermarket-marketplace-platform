// utils/load-more-btn/load-more-btn.component.ts

import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-load-more-btn',
  standalone: true,
  templateUrl: './load-more-btn.component.html',
  styleUrl: './load-more-btn.component.css'
})
export class LoadMoreBtnComponent {

  @Output()
  loadMore = new EventEmitter<void>();

}